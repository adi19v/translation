# Akito Playground

This repository act as the alternative download of [this](https://sourceforge.net/projects/akito/files/).

I will keep updating some stuff here as well so keep your eyes on it

# List of active project

Haruka Aya - Find it [here](https://github.com/peaktogoo/HarukaAya)

and there are some more GSIs buildbot stuff also
